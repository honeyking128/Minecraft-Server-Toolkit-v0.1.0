# ⛏️ Minecraft Server Toolkit

A small open-source **local web dashboard** for managing a Minecraft Java Edition server.

## Features
- Start and stop a local Java server
- Live console output and server commands
- Edit `server.properties`
- One-click world backups
- Configurable server directory via `MC_SERVER_DIR`

## Requirements
- Node.js 20+
- Java version required by your Minecraft server version
- A **legally obtained** Minecraft Java server JAR

## Quick start (Windows)
1. Extract this project.
2. Open Command Prompt/PowerShell in the project folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3210`.
6. A `minecraft-server` folder is created automatically. Put your server JAR there and name it `server.jar`.
7. Click **Start** in the dashboard.

> Starting the server indicates acceptance of Mojang's Minecraft EULA. Review it before running a server. This project does not include or redistribute Minecraft server software.

## Existing server folder
PowerShell: `$env:MC_SERVER_DIR="C:\path\to\server"; npm start`

## Safety
The dashboard listens locally by default. Do not expose it directly to the public internet; it can execute Minecraft console commands. Back up important worlds before testing.

## Roadmap
- Scheduled backups
- Restore UI
- Player list and resource charts
- Multiple server profiles
- Paper/Fabric setup helpers without redistributing their binaries

## License
MIT. Minecraft is a trademark of Microsoft/Mojang; this project is unofficial and unaffiliated.
