const express=require('express');const fs=require('fs');const path=require('path');const {spawn}=require('child_process');const readline=require('readline');
const app=express();app.use(express.json());app.use(express.static('public'));
const ROOT=path.resolve(process.env.MC_SERVER_DIR||path.join(__dirname,'minecraft-server'));const BACKUPS=path.join(__dirname,'data','backups');let proc=null,logs=[];
fs.mkdirSync(ROOT,{recursive:true});fs.mkdirSync(BACKUPS,{recursive:true});
const log=x=>{logs.push(`[${new Date().toLocaleTimeString()}] ${x}`);logs=logs.slice(-500)};
function props(){const f=path.join(ROOT,'server.properties');if(!fs.existsSync(f))return{};return Object.fromEntries(fs.readFileSync(f,'utf8').split(/\r?\n/).filter(x=>x&&!x.startsWith('#')&&x.includes('=')).map(x=>{let i=x.indexOf('=');return[x.slice(0,i),x.slice(i+1)]}))}
function saveProps(o){fs.writeFileSync(path.join(ROOT,'server.properties'),Object.entries(o).map(([k,v])=>`${k}=${String(v).replace(/[\r\n]/g,'')}`).join('\n')+'\n')}
app.get('/api/status',(q,r)=>r.json({running:!!proc,pid:proc?.pid||null,root:ROOT,properties:props(),logs}));
app.post('/api/properties',(q,r)=>{saveProps(q.body||{});log('server.properties updated');r.json({ok:true})});
app.post('/api/start',(q,r)=>{if(proc)return r.status(409).json({error:'Server already running'});let jar=path.join(ROOT,'server.jar');if(!fs.existsSync(jar))return r.status(400).json({error:`Put your legally obtained server.jar in ${ROOT}`});fs.writeFileSync(path.join(ROOT,'eula.txt'),'eula=true\n',{flag:'wx',encoding:'utf8'});proc=spawn('java',['-Xms1G','-Xmx2G','-jar','server.jar','nogui'],{cwd:ROOT});log(`Started PID ${proc.pid}`);for(const s of [proc.stdout,proc.stderr]) readline.createInterface({input:s}).on('line',log);proc.on('exit',c=>{log(`Server exited (${c})`);proc=null});r.json({ok:true,pid:proc.pid})});
app.post('/api/command',(q,r)=>{if(!proc)return r.status(409).json({error:'Server is not running'});const cmd=String(q.body?.command||'').replace(/[\r\n]/g,'').trim();if(!cmd)return r.status(400).json({error:'Empty command'});proc.stdin.write(cmd+'\n');log(`> ${cmd}`);r.json({ok:true})});
app.post('/api/stop',(q,r)=>{if(!proc)return r.status(409).json({error:'Server is not running'});proc.stdin.write('stop\n');r.json({ok:true})});
app.post('/api/backup',(q,r)=>{const world=path.join(ROOT,props()['level-name']||'world');if(!fs.existsSync(world))return r.status(400).json({error:'World folder not found'});const name=`world-${new Date().toISOString().replace(/[:.]/g,'-')}`;const dst=path.join(BACKUPS,name);fs.cpSync(world,dst,{recursive:true});log(`Backup created: ${name}`);r.json({ok:true,name})});
app.get('/api/backups',(q,r)=>r.json(fs.readdirSync(BACKUPS,{withFileTypes:true}).filter(x=>x.isDirectory()).map(x=>x.name).sort().reverse()));
app.listen(process.env.PORT||3210,()=>console.log('Minecraft Server Toolkit: http://localhost:3210'));
